set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
checker=$(bash test/cabal.sh list-bin tui-model-test)
for n in 1 8; do
  printf 'RTS -N%s\n' "$n"
  "$checker" +RTS -N$n -RTS
done
