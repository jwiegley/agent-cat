set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
work=$(mktemp -d "$TMPDIR/tls-dependency.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir "$work/N$n"
  "$CABAL_BUILDDIR/manager-dependency-probe/probe" "$work/N$n" +RTS -N$n -RTS
done
bash test/cabal.sh sdist --output-directory "$work/sdist"
tar -xOf "$work/sdist/agentic-0.1.0.0.tar.gz" agentic-0.1.0.0/nix/crypton-x509-validation-san.patch | cmp - nix/crypton-x509-validation-san.patch
printf 'PASS source archive includes the exact SAN patch\n'
