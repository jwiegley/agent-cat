set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
checker=$(bash test/cabal.sh list-bin tui-model-test)
frontend=$(bash test/cabal.sh list-bin agentic-run)
runner=$(bash test/cabal.sh list-bin routing-fixed-point-probe)
work=$(mktemp -d "$TMPDIR/tui-approval.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  printf 'RTS -N%s\n' "$n"
  "$checker" +RTS -N$n -RTS
  mkdir "$work/N$n"
  TUI_CHECK="$frontend" python3 manager/test/service_http.py "$PWD" "$work/N$n" "$runner" "$n" tui-approval
done
