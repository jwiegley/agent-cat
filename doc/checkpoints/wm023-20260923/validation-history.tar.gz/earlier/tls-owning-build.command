set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
bash test/cabal.sh build agentic-run manager-client-check routing-fixed-point-probe manager-artifact-check --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -fforce-recomp'
build="$CABAL_BUILDDIR/manager-dependency-probe"
mkdir -p "$build"
bash test/cabal.sh exec -- ghc -Wall -Werror -fforce-recomp -threaded -rtsopts \
  -package agentic -package direct-sqlite -package wai -package warp -package warp-tls \
  -package network -package tls -package crypton-connection -package crypton-x509-store \
  -outputdir "$build" manager/test/DependencyProbe.hs -o "$build/probe"
