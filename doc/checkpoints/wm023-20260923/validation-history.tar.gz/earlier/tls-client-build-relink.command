set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
test "$(command -v ghc)" = /nix/store/70qgc49k6yrkbyvbxgsvznb65l83wc9k-ghc-9.10.3-with-packages/bin/ghc
bash test/cabal.sh build agentic-run manager-client-check --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -fforce-recomp'
