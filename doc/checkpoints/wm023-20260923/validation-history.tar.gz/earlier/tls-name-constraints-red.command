set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
checker=$(find "$CABAL_BUILDDIR/build" -path '*/manager-client-check/build/manager-client-check/manager-client-check' -type f)
test -n "$checker" && test -f "$checker"
printf 'Pre-update executable: %s\n' "$checker"
ghc-pkg latest crypton-x509-validation
work=$(mktemp -d "$TMPDIR/constraints-red.XXXXXXXX")
printf 'work=%s\n' "$work"
python3 manager/test/client_native.py "$PWD" "$work" "$checker" 1
