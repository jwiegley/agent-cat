set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/src/agent-cat/.worktrees/tui
make -C doc check
python3 - <<'PY'
from pathlib import Path
import re

def records(path):
    text = re.sub(r'^,(?=\*|#\+)', '', Path(path).read_text(), flags=re.M)
    heads = list(re.finditer(r'^\* .+\n:PROPERTIES:\n', text, re.M))
    result = {}
    for i, head in enumerate(heads):
        block = text[head.start():heads[i + 1].start() if i + 1 < len(heads) else len(text)]
        key = re.search(r'^:ID:\s+(\S+)', block, re.M)
        if key:
            result[key[1]] = block.strip()
    return result

canonical = records('doc/PLAN.org')
authority = records('/Users/johnw/src/agent-cat/doc/PLAN.org')
assert authority.keys() - canonical.keys() == {'acat-3ajx', 'acat-3sq1', 'acat-jg00', 'acat-lijk'}
assert not canonical.keys() - authority.keys()
assert all(canonical[key] == authority[key] for key in canonical)
print(f'PASS {len(canonical)} shared tracker records match; four authority-only records preserved')
PY
git diff --check
git diff --quiet -- flake.nix flake.lock
