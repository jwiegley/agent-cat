set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
test "$(ghc-pkg latest crypton-x509-validation)" = crypton-x509-validation-1.9.1
checker=$(bash test/cabal.sh list-bin manager-client-check)
work=$(mktemp -d "$TMPDIR/tls-client.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir "$work/N$n"
  python3 manager/test/client_native.py "$PWD" "$work/N$n" "$checker" "$n"
done
