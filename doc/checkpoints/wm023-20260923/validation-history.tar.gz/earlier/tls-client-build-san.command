set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
test "$(ghc --numeric-version)" = 9.10.3
test "$(ghc-pkg latest crypton-x509)" = crypton-x509-1.9.1
test "$(ghc-pkg latest crypton-x509-validation)" = crypton-x509-validation-1.9.1
printf '%s\n' "Compiler: $(command -v ghc)"
bash test/cabal.sh build agentic-run manager-client-check --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options=-Werror
