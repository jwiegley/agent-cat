set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
checker=$(bash test/cabal.sh list-bin manager-client-check)
runner=$(bash test/cabal.sh list-bin agentic-run)
work=$(mktemp -d "$TMPDIR/tls-manager.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir "$work/N$n"
  CLIENT_CHECK="$checker" python3 manager/test/service_http.py "$PWD" "$work/N$n" "$runner" "$n"
done
