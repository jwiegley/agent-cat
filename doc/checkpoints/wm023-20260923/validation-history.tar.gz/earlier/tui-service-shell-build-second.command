set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
bash test/cabal.sh build agentic-run tui-model-test --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -threaded -rtsopts'
