set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/src/agent-cat/.worktrees/tui
make -C doc check-haskell
