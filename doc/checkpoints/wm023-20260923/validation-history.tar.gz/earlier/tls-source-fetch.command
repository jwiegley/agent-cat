nix-prefetch-url --unpack official Hackage crypton-x509{,-validation}-1.9.1 tarballs; nix hash convert --hash-algo sha256 --to sri
