set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/src/agent-cat/.worktrees/tui
bash test/cabal.sh build lib:agentic --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -fforce-recomp'
build="$CABAL_BUILDDIR/manager-dependency-probe"
bash test/cabal.sh exec -- ghc -Wall -Werror -fforce-recomp -threaded -rtsopts \
  -package-id agentic-0.1.0.0-inplace -package direct-sqlite -package wai -package warp -package warp-tls \
  -package network -package tls -package crypton-connection -package crypton-x509-store \
  -outputdir "$build" manager/test/DependencyProbe.hs -o "$build/probe"
work=$(mktemp -d "$TMPDIR/tls-canonical.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir "$work/N$n"
  "$build/probe" "$work/N$n" +RTS -N$n -RTS
done
# sdist is local-only and does not accept Cabal's --offline flag.
cabal --store-dir="$CABAL_BUILDDIR/cabal-store" --active-repositories=:none sdist --builddir="$CABAL_BUILDDIR" --output-directory "$work/sdist"
tar -xOf "$work/sdist/agentic-0.1.0.0.tar.gz" agentic-0.1.0.0/nix/crypton-x509-validation-san.patch | cmp - nix/crypton-x509-validation-san.patch
printf 'PASS source archive includes the exact SAN patch\n'
make -C doc check
make -C doc check-haskell
git diff --check
