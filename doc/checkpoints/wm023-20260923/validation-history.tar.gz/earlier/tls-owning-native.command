set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source
build="$CABAL_BUILDDIR/manager-dependency-probe"
bash test/cabal.sh exec -- ghc -Wall -Werror -fforce-recomp -threaded -rtsopts \
  -package-id agentic-0.1.0.0-inplace -package direct-sqlite -package wai -package warp -package warp-tls \
  -package network -package tls -package crypton-connection -package crypton-x509-store \
  -outputdir "$build" manager/test/DependencyProbe.hs -o "$build/probe"
work=$(mktemp -d "$TMPDIR/tls-owning.XXXXXXXX")
printf 'work=%s\n' "$work"
checker=$(bash test/cabal.sh list-bin manager-artifact-check)
runner=$(bash test/cabal.sh list-bin routing-fixed-point-probe)
client=$(bash test/cabal.sh list-bin manager-client-check)
for n in 1 8; do
  mkdir -p "$work/N$n/dependencies" "$work/N$n/admission" "$work/N$n/http"
  "$build/probe" "$work/N$n/dependencies" +RTS -N$n -RTS
  "$checker" admission-contention "$work/N$n/admission" +RTS -N$n -M512m -RTS
  CLIENT_CHECK="$client" python3 manager/test/service_http.py "$PWD" "$work/N$n/http" "$runner" "$n" mixed-confirm
done
bash test/cabal.sh sdist --output-directory "$work/sdist"
tar -xOf "$work/sdist/agentic-0.1.0.0.tar.gz" agentic-0.1.0.0/nix/crypton-x509-validation-san.patch | cmp - nix/crypton-x509-validation-san.patch
printf 'PASS source archive includes the exact SAN patch\n'
