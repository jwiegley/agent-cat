set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
nix build --no-link --print-out-paths --no-write-lock-file --option builders '' --cores 4 --max-jobs 2 --impure --expr 'let f = builtins.getFlake "git+file:/Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/broker-source"; compiler = builtins.head f.devShells.aarch64-darwin.default.buildInputs; in assert compiler.name == "ghc-9.10.3-with-packages"; compiler'
