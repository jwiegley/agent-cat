bash manager/ci/contract.sh
