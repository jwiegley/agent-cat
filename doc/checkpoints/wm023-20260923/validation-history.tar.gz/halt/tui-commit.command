set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/halt-20260923/verify-source
test "$(git rev-parse HEAD)" = d8c0609a7ea1b22dc70e863a288a1fa15fc46325
bash test/cabal.sh build agentic-run tui-model-test routing-fixed-point-probe --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -threaded -rtsopts'
checker=$(bash test/cabal.sh list-bin tui-model-test)
frontend=$(bash test/cabal.sh list-bin agentic-run)
runner=$(bash test/cabal.sh list-bin routing-fixed-point-probe)
work=$(mktemp -d "$TMPDIR/halt-tui.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  "$checker" +RTS -N$n -RTS
  mkdir "$work/N$n"
  TUI_CHECK="$frontend" python3 manager/test/service_http.py "$PWD" "$work/N$n" "$runner" "$n" tui-approval
done
runghc -package=ghc -package=Cabal-syntax test/source-boundaries.hs "$(ghc --print-libdir)"
