set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
export PATH=/nix/store/11329fmv4dv6icqqdrqvkq9kls6mkwc5-ghc-9.10.3-with-packages/bin:$PATH
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/source
test "$(git rev-parse HEAD)" = 74ad50e93de6a0ff301142b24784fccf6d81a88c
test "$(ghc --numeric-version)" = 9.10.3
test "$(ghc-pkg latest crypton-x509)" = crypton-x509-1.7.7
bash test/cabal.sh build lib:agentic --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options=-Werror
