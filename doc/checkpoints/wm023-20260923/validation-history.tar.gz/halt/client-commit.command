set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/halt-20260923/verify-source
test "$(git rev-parse HEAD)" = 073508ff759addf9dcdf6e643e5e6bac2783efba
bash test/cabal.sh build agentic-run manager-client-check --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -threaded -rtsopts'
runner=$(bash test/cabal.sh list-bin agentic-run)
checker=$(bash test/cabal.sh list-bin manager-client-check)
work=$(mktemp -d "$TMPDIR/halt-client.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir -p "$work/N$n/external" "$work/N$n/http"
  python3 manager/test/client_native.py "$PWD" "$work/N$n/external" "$checker" "$n"
  CLIENT_CHECK="$checker" python3 manager/test/service_http.py "$PWD" "$work/N$n/http" "$runner" "$n"
done
