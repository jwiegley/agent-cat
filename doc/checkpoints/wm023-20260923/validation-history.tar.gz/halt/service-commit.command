set -euo pipefail
source /Users/johnw/Products/k.M0a5ItPm/environment.sh
cd /Users/johnw/Products/agent-cat-workflow-manager/implementation.9tGzKH/service-tui.purvEwEv/halt-20260923/verify-source
test "$(git rev-parse HEAD)" = 910db08405b3240276b5edc14d90439ec9e5ef1f
bash test/cabal.sh build agentic-run manager-artifact-check --with-compiler="$(command -v ghc)" --with-hc-pkg="$(command -v ghc-pkg)" --ghc-options='-Werror -threaded -rtsopts -fforce-recomp'
runner=$(bash test/cabal.sh list-bin agentic-run)
checker=$(bash test/cabal.sh list-bin manager-artifact-check)
work=$(mktemp -d "$TMPDIR/halt-service.XXXXXXXX")
printf 'work=%s\n' "$work"
for n in 1 8; do
  mkdir -p "$work/N$n/http" "$work/N$n/order" "$work/N$n/observation"
  "$checker" response-order "$work/N$n/order" +RTS -N$n -M512m -RTS
  "$checker" observation "$work/N$n/observation" +RTS -N$n -M512m -RTS
  python3 manager/test/artifact_contract.py "$PWD" "$work/N$n/observation" observation
  python3 manager/test/service_http.py "$PWD" "$work/N$n/http" "$runner" "$n"
done
